students = [
    {
        "id": 1,
        "name": "Yashas",
        "email": "yashas@example.com"
    },
    {
        "id": 2,
        "name": "Rahul",
        "email": "rahul@gmail.com"
    }
]